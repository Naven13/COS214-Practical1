#ifndef EVENT_H
#define EVENT_H

enum Event {
    SOIL_CHANGE,
    STORAGE_FULL
};
#endif //EVENT_H
